<?php 
	if (!isset($_GET["assignment_id"])){
		exit();
	}
	$assignment_id = $_GET["assignment_id"];
	//echo("xx $assignment_id xx");
?>
<html>
<head>
		<title>APT Online Test</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	

		<link href="css/cat.css" type="text/css" rel="stylesheet">
		<script language ="javascript" src="js/jquery/jquery.min.js"></script>
		<script language ="javascript" src="js/mustache/mustache.js"></script>
		<script language ="javascript" src="js/PageBase.js"></script>
		
		<script language ="javascript" src="form/conductTest/dev01.js"></script>
		<script language ="javascript">
			var JsController = new Dev01Controller('<?php echo($assignment_id); ?>');
			JsController.OnLoad();
			window.onscroll = function() {PageHeaderFix()};
		</script>
</head>
<body>
	<div style="overflow:auto" class="top_banner" id="topping">
		<div class="top_ins"><img src="img/APEC-LOGO.png"></div>
		<div class="top_header"><div style="font-family: tahoma;">Apt Training Resources</br>MCQ Challenge<br>(Online Test Platform)
			</br></br><span id="myDbMsg" style="display:none;color:orange;"></span></div></div>
		<div class="top_comp"><img src="img/logo.png"></div>
	</div>
	<div style="overflow:auto" class="heading_view" id="myHeader">
		<div class="heading_data" id="myTitle">Student Test Platform</div>
		<div class="heading_logout" style="display:table;">
		<div style="display:table-cell;text-align:right; vertical-align: middle; color: white; font-family: Arial; font-weight: bold; font-size: 12pt;"><span>Welcome </span><span id="myUserName">-</span><span>(</span><span id="myFullName">-</span><span>)! </span></div>
		<div style="display:table-cell;"><a href="logout.php" border="1">Logout</a></div></div>
	</div>
	<div style="overflow:auto" class="main_view">
		<div class="main_menus">
			<div id="menuContent">
			</div>
			<div id="testPagers" style="display:none;">
			</div>
		</div>
		<div class="main_data">
			<div id="pageContent">
			</div>
		</div>
	</div>
	
	<div id="AppDeb">Details:
		<div id="act01">
		<input type="button" value="Def Data" onclick="JsController.act.act1();">
		<input type="button" value="Edit Data" onclick="JsController.act.act2();">
		<input type="button" value="Disp Data" onclick="JsController.act.act3();">
		<input type="button" value="Rend Data" onclick="JsController.act.act4();">
		</div>
		<div id="act02"></div>
		<div id="act03"></div>
		<div id="act04"></div>
		<div id="act05"></div>
		<div 
	</div>
</body>
</html>		 