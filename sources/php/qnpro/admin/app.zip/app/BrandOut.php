<style type="text/css">

.brand-prd-desc{
display:inline-block; width: 300px;
padding:5px;
	margin:1%;
background: #ADA996;

    background: -webkit-linear-gradient(to right, #EAEAEA, #DBDBDB, #F2F2F2, #ADA996);
    background: linear-gradient(to right, #EAEAEA, #DBDBDB, #F2F2F2, #ADA996);
	 
	color:navy;

	border-radius:50px; 
	font-size:12pt;font-variant:small-caps;
}
.brand-each{		display: table-cell; 		
		padding:5px;
		margin:1%;
		color:#f4f5f7; font-family: tahoma; font-size:18pt;font-weight:bold; 
				border-radius:20px;
		border:1px solid #434343;		
background: #000000;  /* fallback for old browsers */
background: -webkit-linear-gradient(to left, #434343, #000000);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to left, #434343, #000000); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
		font-variant:small-caps;
		vertical-align:middle;
		text-align: center;	}
.comp-each{		display: table-cell; 		
		padding:5px;
		margin:1%;
		color:#c44844; font-family: tahoma; font-size:18pt;font-weight:bold; 
		border-radius:20px;
		border:1px solid #f4f5f7;		
background: #f4f5f7;  /* fallback for old browsers */
background: -webkit-linear-gradient(to left, #ffffff, #f4f5f7);  /* Chrome 10-25, Safari 5.1-6 */
background: linear-gradient(to left, #ffffff, #f4f5f7); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
		
		vertical-align:middle;
		text-align: center;	}		
</style>





<div style="font-family: tahoma;" >			
	<div>
		<table align="center"><tr><td>
		<span class="comp-each">&nbsp;&nbsp;Apt&nbsp;&nbsp;</span>
		<span  class="comp-each">&nbsp;&nbsp;Training&nbsp;&nbsp;</span>
		<span  class="comp-each">&nbsp;&nbsp;Resources&nbsp;&nbsp;</span>
		</td><tr></table>
	</div>
<!--div>
	<table align="center"><tr><td>
		<span class="brand-each">M</span><span class="brand-each">C</span>
		<span class="brand-each">Q</span> 
		<span class="brand-each">Challenge</span>
	</td><tr></table>
</div-->
<div>
	<span  class="brand-prd-desc">Online Test Platform</span>
</div>
</div>
<div>
	<span id="myDbMsg" style="color:white;">
		&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;			
	</span>
</div>
			