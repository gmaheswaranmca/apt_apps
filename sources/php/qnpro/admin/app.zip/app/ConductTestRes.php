<?php 
	if (!isset($_GET["assignment_id"])){
		exit();
	}
	$assignment_id = $_GET["assignment_id"];
	//echo("xx $assignment_id xx");
?>
<html>
<head>
		<title>APT Online Test</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	

		<link href="css/cat.css" type="text/css" rel="stylesheet">
		<script language ="javascript" src="js/jquery/jquery.min.js"></script>
		<script language ="javascript" src="js/mustache/mustache.js"></script>
		<script language ="javascript" src="js/PageBase.js"></script>
		
		<script language ="javascript" src="form/conductTest/conductTest.js"></script><script language ="javascript" src="form/conductTest/conductTestMisc.js"></script>
		<script language ="javascript">
			var JsController = new ConductTestJsController('<?php echo($assignment_id); ?>');
			JsController.OnLoad();
			window.onscroll = function() {PageHeaderFix()};
		</script>
</head>

<body>
	<div style="overflow:auto" class="top_banner" id="topping">
		<div class="top_ins"><img src="img/APEC-LOGO.png">
		</div>
		<div class="top_header brand">
			<?php include("BrandOut.php")?>				
		</div>	
		<div class="top_comp"><img src="img/logo.png">
			<div style="width:100%">
				<table width="100%">
				<tr>
					<td class="tmrBox" align="center"><div style="width:100%" id="myRemainingTime">&nbsp;&nbsp;&nbsp;&nbsp;</div></td>
				</tr>
				</table>
			</div>
		</div>
	</div>
	<div style="overflow:auto" class="heading_view" id="myHeader">
		<div class="heading_data" id="myTitle">Student Test Platform</div>
		<div class="heading_logout" style="display:table;">
		<div style="display:table-cell;text-align:right; vertical-align: middle; color: white; font-family: Arial; font-weight: bold; font-size: 12pt;"><span>Welcome </span><span id="myUserName">-</span><span>(</span><span id="myFullName">-</span><span>)! </span></div>
		<div style="display:table-cell;"><a href="logout.php" border="1">Logout</a></div></div>
	</div>
	<div style="overflow:auto" class="main_view">
		<div class="main_menus">
			<div id="menuContent">
			</div>
			<div id="testPagers" style="display:none;">
			</div>
		</div>
		<div class="main_data">
		
		

			<div id="pageContent">
			</div>
		</div>
	</div>
	
	<!--div id="AppDeb">Details:
		<div id="DebTitle"></div>
		<div id="DebPage"></div>
		<div id="DebUser"></div>
		<div id="DebMenuContent"></div>
		<div id="DebFullName"></div>
	</div-->
</body>
</html>	



		

