function CategoryJsController(){
	this.pgHtml = "";
	this.menuHtml = "";
    this.pgQueryRes = {};	
	this.OnLoad=function(){		
		this.QPgHtml();		
	};
	this.EditCategory=function(cat_id){
		//alert("weo" + cat_id);
		$("#MsgDev").html( "Edit " + cat_id);	
		return false;
	};
	this.DeleteCategory=function(cat_id)
	{
		$("#MsgDev").html( "Delete " + cat_id);
		return false;
	};
	this.AddCategory=function()
	{
		$("#MsgDev").html( "Add / Save ");
		return false;
	};
	this.QPgHtml=function()	// QPgHtml -> QListData -> ParsePgHtmlWListData
	{
		$.post("form/category/v2mCategory.php",  { m: "html"}, 
			function(htmlData){
				JsController.pgHtml = htmlData;
				JsController.QListData();
				JsController.QMenuHtml()
			}
		);
	};
	this.QListData=function(){
		$.post("form/category/v2mCategory.php",  { m: "daoquery_list"},
			function(queryData){
				JsController.pgQueryRes = queryData;
				JsController.ParsePgHtmlWListData();
			}
		);	
	};
	this.ParsePgHtmlWListData=function(){
		var v_r = JsController.pgQueryRes.r;
		var rendered = Mustache.render(JsController.pgHtml,{category_list: v_r});
		$("#pageContent").html(rendered);
	}
	this.QMenuHtml=function()	// QMenuHtml -> QMenuData 
	{
		$.post("form/category/v2mCategory.php",  { m: "menu_htm"}, 
			function(htmlData){
				JsController.menuHtml = htmlData;
				JsController.QMenuData();
			}
		);
	};
	this.QMenuData=function(){
		$.post("form/category/v2mCategory.php",  { m: "daomodule_get"},
			function(queryData){				
				var v_r = queryData.r;
				var rendered = Mustache.render(JsController.menuHtml,{menus: v_r});
				$("#menuContent").html(rendered);
			}
		);	
	};
};
