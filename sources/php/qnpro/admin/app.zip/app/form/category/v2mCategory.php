<?php 

   $RUN = 1;
   
?>
<?php 
  if(!isset($RUN)) { exit(); } 
  
?>
<?php 
if (!defined('FS_DIR_CATEGORY_PC')) { /* FS: File System, PC: Page Controller */
define('FS_DIR_CATEGORY_PC', __DIR__.'/');
}

$util_path = realpath(FS_DIR_CATEGORY_PC.'../../sdk/ar6PhpUtil.php');	
$db_path = realpath(FS_DIR_CATEGORY_PC.'CategoryDb.php');
$module_db_path = realpath(FS_DIR_CATEGORY_PC.'../userAndModule/UserAndModuleDb.php');	

include ($util_path);
include ($db_path);
include ($module_db_path);



class CategoryPageController	// change 1b
{
	private $m_method = ''; 
	private $phpUtil = null;
	
	public function __construct()
	{
		global $phpUtil;
		$this->phpUtil = $phpUtil;
		$this->frm_init();
	}
	
	public function frm_init(){
		UserAndModuleDb::allow("1"); // Role Based Access
		
		$v_m = $this->phpUtil->field('m','');
		
		if(!($v_m==='')){
			switch($v_m)
			{
				case 'html':	// change 2a
					$html_page = realpath(FS_DIR_CATEGORY_PC.'CategoryView.php');
					//echo "aa $html_page bb<br>";
					$this->phpUtil->output_form_init($html_page); // change 2b	
					break;
				case 'menu_htm':	// change 2a
					$html_page = realpath(FS_DIR_CATEGORY_PC.'../userAndModule/MenusView.php');
					//echo "aa $html_page bb<br>";
					$this->phpUtil->output_form_init($html_page); // change 2b	
					break;	
				/* case 'js': // change 2e
					$this->phpUtil->output_form_init('category.js'); // change 2f
					break;
				*/	
				case 'daoquery_list':
					$this->BmQueryCategoryList();
					break;
				case 'daoquery_byid':
					$this->BmQueryCategoryById();	
					break;
				case 'daodelete':
					$this->BmDeleteCategory();	
					break;
				case 'daosave':
					$this->BmSaveCategory();	
					break;
				case 'daomodule_get':
					$this->BmQueryModuleGet();	
					break;	
			}
		}
	}
	/*2. dao-read*/
		public function BmQueryCategoryList()
		{
			//input
			//process
			$v_r_no = 989;
			{
				$oCategoryDb = new CategoryDb();	// change 3a
				$v_dao_result = $oCategoryDb->QueryCategoryList();	// change 3b
				$v_r_no = 1;
			}	
			//output
			$v_out='';
			switch($v_r_no){
				case 1:
					$v_out = $this->phpUtil->output($v_r_no, '', $v_dao_result);
					break;
				case 989:
					$v_out = $this->phpUtil->output($v_r_no, 'Query Not Possible, Invalid Operation', '');
					break;
				case 988:
					$v_out = $this->phpUtil->output($v_r_no, 'Query Not Possible, Invalid Operation', '');
					break;	
			}
			header('Content-Type: application/json');
			echo($v_out);
			return $v_out;
		}
	
		public function BmQueryCategoryById()
		{
			//input
			$v_category_id = $this->phpUtil->field('category_id'); // change 4a
			
			//process
			$v_r_no = 989;
			{
				$oCategoryDb = new CategoryDb();	// change 4b
				$v_dao_result = $oCategoryDb->QueryCategoryById($v_category_id);	// change 4c
				$v_r_no = 1;
			}
			//output
			$v_out='';
			switch($v_r_no){
				case 1:
					$v_out = $this->phpUtil->output($v_r_no, '', $v_dao_result);
					break;
				case 989:
					$v_out = $this->phpUtil->output($v_r_no, 'Query Not Possible, Invalid Operation', '');
					break;
				case 988:
					$v_out = $this->phpUtil->output($v_r_no, 'Query Not Possible, Invalid Operation', '');
					break;	
			}
			header('Content-Type: application/json');
			echo($v_out);
			return $v_out;
		}
		public function BmQueryModuleGet()
		{
			//input
			$p_user = $_SESSION['txtLogin'];
			$p_password = $_SESSION['txtPass'];
			$p_imp_password = $_SESSION['txtPassImp'];
			$p_check_pass = true;			
			//process
			$v_r_no = 989;
			{
				$oUserAndModuleDb = new UserAndModuleDb();	// change 4b
				$v_dao_result = $oUserAndModuleDb->GetModules($p_user, $p_password, $p_imp_password, $p_check_pass);	// change 4c
				//echo($v_dao_result);
				$v_r_no = 1;
			}
			//output
			$v_out='';
			switch($v_r_no){
				case 1:
					$v_out = $this->phpUtil->output($v_r_no, '', $v_dao_result);
					break;
				case 989:
					$v_out = $this->phpUtil->output($v_r_no, 'Query Not Possible, Invalid Operation', '');
					break;
				case 988:
					$v_out = $this->phpUtil->output($v_r_no, 'Query Not Possible, Invalid Operation', '');
					break;	
			}
			header('Content-Type: application/json');
			echo($v_out);
			return $v_out;
		}
	/*3. dao-write*/
		public function BmDeleteCategory()
		{
			//input: id 
			$v_category_id = $this->phpUtil->field('category_id');;
			//process
			$v_r_no = 989;
			if(!($v_category_id === '')){		
				$oCategoryDb = new CategoryDb();	// change 5a
				$v_dao_result = $oCategoryDb->DeleteCategory($v_category_id); // change 5b
				
				$v_r_no = 1;
			}
			//output
			$v_out='';
			switch($v_r_no){
				case 1:
					$v_out = $this->phpUtil->output($v_r_no, 'Category Deleted Successfully', '');	// change 5c
					break;
				case 989:
					$v_out = $this->phpUtil->output($v_r_no, 'Delete Not Possible, Invalid Operation', '');
					break;
				case 988:
					$v_out = $this->phpUtil->output($v_r_no, 'Delete Not Possible, Invalid Operation', '');
					break;	
			}
			header('Content-Type: application/json');
			echo($v_out);
			return $v_out;
		}
		
		public function BmSaveCategory()
		{
			//input
			$v_category_id = $this->phpUtil->field('category_id');	// change 6a
			$v_category_name = $this->phpUtil->field('category_name'); // change 6a			
			
			$v_debug_str = $v_category_id . ',' . $v_category_name;
			//process "";//
			$v_r_no = 989;
			if(!($v_category_id === '')){		// change 6b
				if($v_category_id === '0'){	// change 6c
					$oCategoryDb = new CategoryDb();	// change 6d
					$v_dao_result = $oCategoryDb->InsertCategory($v_category_name);	// change 6e
					$v_r_no = 1;
				}else{
					$oCategoryDb = new CategoryDb();	// change 6f
					$v_dao_result = $oCategoryDb->UpdateCategory($v_category_name, $v_category_id);	// change 6g
					$v_r_no = 2;
				}			
			}
			//output
			switch($v_r_no){
				case 1:
					$v_out = $this->phpUtil->output($v_r_no, 'Category Created Successfully', $v_debug_str);	// change 6h
					break;
				case 2:
					$v_out = $this->phpUtil->output($v_r_no, 'Category Updated Successfully', $v_debug_str); // change 6i
					break;	
				case 989:
					$v_out = $this->phpUtil->output($v_r_no, 'Save Not Possible, Invalid Operation', $v_debug_str);
					break;
				case 988:
					$v_out = $this->phpUtil->output($v_r_no, 'Save Not Possible, Invalid Operation', $v_debug_str);
					break;	
			}
			header('Content-Type: application/json');
			echo($v_out);
			return $v_out;
		}
}

$oCategoryPageController = new CategoryPageController();	// change 7

?>