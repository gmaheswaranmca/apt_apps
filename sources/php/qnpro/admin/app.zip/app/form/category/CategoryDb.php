<?php if(!isset($RUN)) { exit(); } ?>
<?php 
if (!defined('ROOTDB')) {
define('ROOTDB', __DIR__.'/');
}
$dbbase_path = realpath(ROOTDB.'../../sdk/ar6PhpMySqlDao.php');	
/*
echo("aa". $dbbase_path . "bb<br>");
if (file_exists($dbbase_path)) {
	echo("aa File Exists bb<br>");
}
*/
include_once ($dbbase_path);

class CategoryDb	
{
	private $m_dao = NULL;
	
	public function __construct()
	{
		$this->m_dao = new ar6PhpMySqlDao();
	}
	
	public function InsertCategory($p_category_name)	// change 2a
	{
		$v_sql = "INSERT INTO cats(cat_name) VALUES(:p_category_name)"; // change 2b
		$v_param = array("p_category_name"=>$p_category_name); // change 2c
		
		$v_result = $this->m_dao->db_write($v_sql, $v_param);
		return $v_result;
	}
	
	public function UpdateCategory($p_category_name, $p_category_id)	// change 3a
	{
		$v_sql = "UPDATE cats SET cat_name=:p_category_name WHERE id=:p_category_id";	// change 3b
		$v_param = array("p_category_name"=>$p_category_name, "p_category_id"=>$p_category_id); // change 3c
		
		$v_result = $this->m_dao->db_write($v_sql, $v_param);
		return $v_result;
	}
	
	public function DeleteCategory($p_category_id)	// change 4a
	{
		$v_sql = "DELETE FROM cats WHERE id=:p_category_id"; // change 4b
		$v_param = array("p_category_id"=>$p_category_id); // change 4c
		
		$v_result = $this->m_dao->db_write($v_sql, $v_param);
		return $v_result;
	}
	
	public function QueryCategoryById($p_category_id)	// change 5a
	{
		$v_sql = "SELECT * FROM cats WHERE id=:p_category_id"; // change 5b
		$v_param = array("p_category_id"=>$p_category_id);	// change 5c
		
		$v_result = $this->m_dao->db_read($v_sql, $v_param, 1); 
		
		if ($v_result === true)
		{	
			return $this->m_dao->getResult();			
		}
		return $v_result;
	}
	
	public function QueryCategoryList()	// change 6a
	{
		$v_sql = "SELECT * FROM cats"; // change 6b
		$v_param = array(); // change 6c
		
		$v_result = $this->m_dao->db_read($v_sql, $v_param, 1);
		if ($v_result === true)
		{	
			return $this->m_dao->getResult();
		}
		return $v_result;
	}
}
?>