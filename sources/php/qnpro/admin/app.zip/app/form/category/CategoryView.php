<?php 
	
?>

<table>
        <tr>
            <td class="desc_text">
                <span id="MsgDev">xxx</span>
            </td>
        </tr>
</table>
<table class="tblGrid">
	<tr class="c_list_head">
		<td>Category name</td>
		<td>&nbsp;&nbsp;</td>
		<td>&nbsp;&nbsp;</td>
	</tr>
	{{#category_list}}
	<tr class="c_list_item">
		<td>{{cat_name}}</td>
		<td><a href="#" onclick="return JsController.EditCategory('{{id}}');">Edit</a></td>
		<td><a href="#" onclick="return JsController.DeleteCategory('{{id}}');">Delete</a></td>
	</tr>
	{{/category_list}}
	{{^category_list}}
		<tr class="c_list_item">
		<td>No Category Found.</td>
		<td>&nbsp;</td>
		<td>&nbsp;</td>
	</tr>
	{{/category_list}}
</table>	
<table width="100%">
        <tr height="200px" class="c_list_item">
            <td>
                Name : <input type="text" id="txtName" name="txtName"> <input type="button" class="st_button" id="btnAdd" onclick="JsController.AddCategory()" value="Add">
            </td>
        </tr>
</table>
