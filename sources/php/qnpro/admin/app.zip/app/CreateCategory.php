<?
?>
<html>
	<head>
		<title>APT Online Test</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	
		<link href="css/index.css" type="text/css" rel="stylesheet">
		<link href="css/grid.css" type="text/css" rel="stylesheet">
		<script language ="javascript" src="js/jquery/jquery.min.js"></script>
		<script language ="javascript" src="js/mustache/mustache.js"></script>
		
		<script language ="javascript" src="form/category/category.js"></script>
		<script language ="javascript">
			var JsController = new CategoryJsController();
			JsController.OnLoad();
		</script>
	</head>
	<body bgcolor="#97A3AF">
		<table width="100%" cellpadding="0" cellspacing="0" border="0">
           <tr valign="middle">
                <td style="">
                    <div class="logo_block"><img src="img/APEC-LOGO.png" width="200"></div>
                </td>
                <td>
                </td>
                <td valign="middle">
                    <table border="0" cellpadding="0" cellspacing="0" width="100%">
                        <tbody><tr valign="middle">
                            <td valign="middle" align="center">
                                <!--<img src="style/i/bg_3.gif" />--><div class="main_heading">Online Test</div>
                            </td>
                            <td align="right" style="width:200px;">  
								<img src="img/logo.png" alt="Logo" width="80%">
                            </td>
                        </tr>
                    </tbody></table>
                </td>
            </tr>
            <tr>
                <td class="c_menu_td" valign="top">
					
					
         <table>
                 <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=cats"><div class="c_menu_list_bg">Categories</div></a>                                                            </td>
															
                                                            </tr>
                                                                                                                        <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=quizzes"><div class="c_menu_list_bg">Quizzes</div></a>                                                            </td>
                                                            </tr>
                                                                                                                        <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=add_edit_quiz"><div class="c_menu_list_bg">New Quiz</div></a>                                                            </td>
                                                            </tr>
                                                                                                                        <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=local_users"><div class="c_menu_list_bg">Local users</div></a>                                                            </td>
                                                            </tr>
                                                                                                                        <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=add_edit_user"><div class="c_menu_list_bg">New user</div></a>                                                            </td>
                                                            </tr>
                                                                                                                        <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=assignments"><div class="c_menu_list_bg">Assignments</div></a>                                                            </td>
                                                            </tr>
                                                                                                                        <tr>
                                                            <td>
                                                            <a class="menu_child_name" href="index.php?module=add_assignment"><div class="c_menu_list_bg">New Assignment</div></a>                                                            </td>
                                                            </tr>
                                                                                                            
                                        </table>
					
                </td>
                <td width="15px"></td>
                <td align="center" valign="top" bgcolor="#F4F5F7">
                          <table width="95%" cellpadding="0" cellspacing="0" border="0">
                                <tr>
                                    <td align="right">
                                        <a href="logout.php" border="1"><img border="0" src="img/logout.gif"></a>&nbsp;&nbsp;&nbsp;
                                    </td>
                                </tr>
                                <tr>                                    
                                        <td valign="top" bgcolor="#F4F5F7">
                                         
                                                    
                                                                <table width="100%" cellspacing="0" cellpadding="0">
                                                                    <tbody><tr>
                                                                        <td class="main_table_desc_text">
                                                                            <font color="black">
                                                                                Categories                                                                            </font>
                                                                        </td>                                                                       
                                                                    </tr>
                                                                    <tr>
                                                                        <td><br><hr><br></td>
                                                                    </tr>
                                                                </tbody></table>
                                                          
                                                    </td>
                                                                                                    
                                    </tr>
                                    <tr height="550px">
                                        <td valign="top">
                                             <div id="pageContent">
											 </div>

    
    

                                        </td>
                                    </tr>
                            </table>

                </td>
            </tr>

		 </table>
	</body>
</html>		 