<?php 
class ar6PhpUtil
{
	public function __construct()
	{
		
	}
	
	public function field($name, $default=''){
		$v_f = $default;
		if (isset($_GET[$name])){
			$v_f = $_GET[$name];
		}elseif (isset($_POST[$name])){
			$v_f = $_POST[$name];
		}
		
		return $v_f;
	}
	
	public function output($p_r_code, $p_r_msg, $p_r){
		$v_return = array("r_code"=>$p_r_code, "r_msg"=>$p_r_msg, "r"=>$p_r);
		$v_return = $this->arr_to_json($v_return);		
		return $v_return;
	}
	
	public function arr_to_json($p_arr){
		$v_return = json_encode($p_arr);		
		return $v_return;
	}
	
	public function output_form($p_frm){
		//echo "aa $p_frm bb<br>";
		ob_start();
		include $p_frm;
		$v_return = ob_get_clean();
		/*
			$v_return = ob_get_contents();
			ob_end_clean();
		*/
		return $v_return;
	}
	
	public function output_form_init($p_frm)
	{	//user-lookup/form-user-lookup.php
		$v_out=''; 
		$v_out=$this->output_form($p_frm); 
		echo($v_out);
		return $v_out;
	}
	
	public function Now()
	{
		return date('Y-m-d H:i:s');
	}
}

$phpUtil = new ar6PhpUtil();	

?>

