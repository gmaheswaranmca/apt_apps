<?

?>
<html>
<head>
		<title>APT Online Test</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	

		<link href="css/cat.css" type="text/css" rel="stylesheet">
		<script language ="javascript" src="js/jquery/jquery.min.js"></script>
		<script language ="javascript" src="js/mustache/mustache.js"></script>
		<script language ="javascript" src="js/PageBase.js"></script>
		
		<script language ="javascript" src="form/category/category.js"></script>
		<script language ="javascript">
			var JsController = new CategoryJsController();
			JsController.OnLoad();
			window.onscroll = function() {PageHeaderFix()};
		</script>
</head>
<body>
	<div style="overflow:auto" class="top_banner" id="topping">
		<div class="top_ins"><img src="img/APEC-LOGO.png"></div>
		<div class="top_header"><div>APT ONLINE TEST</div></div>
		<div class="top_comp"><img src="img/logo.png"></div>
	</div>
	<div style="overflow:auto" class="heading_view" id="myHeader">
		<div class="heading_data">Categories</div>
		<div class="heading_logout"><a href="logout.php" border="1">Logout</a>&nbsp;&nbsp;&nbsp;</div>
	</div>
	<div style="overflow:auto" class="main_view">
		<div class="main_menus">
			<div id="menuContent">
			</div>
		</div>
		<div class="main_data">
			<div id="pageContent">
			</div>
		</div>
	</div>
</body>
</html>		 