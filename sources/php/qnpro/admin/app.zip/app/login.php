<html>
<head>
		<title>APT Online Test</title>
		<meta name="viewport" content="width=device-width, initial-scale=1.0">	

		<link href="css/cat.css" type="text/css" rel="stylesheet">
		<script language ="javascript" src="js/jquery/jquery.min.js"></script>
		<script language ="javascript" src="js/mustache/mustache.js"></script>
		
		<script language ="javascript" src="form/conductTest/login.js"></script>
		<script language ="javascript">
			var JsController = new LoginJsController();
			JsController.OnLoad();
		</script>
</head>
<style type="text/css">
body{
background: #ADA996;  /* fallback for old browsers */
background: -webkit-radial-gradient(#ADA996, #EAEAEA);  /* Chrome 10-25, Safari 5.1-6 */
background: radial-gradient(#bdc3c7, #2c3e50);/* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
}
</style>
<body>	



	<div style="height: 100%;  display: flex;  align-items: center;  justify-content: center;">
		<div>
			<div id="pageContent">
			</div>
		</div>
	</div>
</body>
</html>		 